const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data", "articles.json");

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname, "public")));

function readArticles(){
  try { return JSON.parse(fs.readFileSync(DATA,"utf8")); }
  catch(e){ return []; }
}
function writeArticles(items){
  fs.writeFileSync(DATA, JSON.stringify(items,null,2), "utf8");
}

app.get("/api/articles", (req,res)=>{
  const q = String(req.query.q||"").trim().toLowerCase();
  const cat = String(req.query.category||"").trim();
  let items = readArticles();
  if(q) items = items.filter(a => `${a.title} ${a.excerpt} ${a.category} ${a.tags.join(" ")}`.toLowerCase().includes(q));
  if(cat) items = items.filter(a => a.category === cat);
  res.json(items);
});

app.get("/api/articles/:id",(req,res)=>{
  const item = readArticles().find(a=>String(a.id)===String(req.params.id));
  if(!item) return res.status(404).json({error:"المقال غير موجود"});
  res.json(item);
});

app.post("/api/articles",(req,res)=>{
  const {title,category,excerpt,content,tags=[]} = req.body || {};
  if(!title || !category || !content) return res.status(400).json({error:"العنوان والقسم والمحتوى مطلوبة"});
  const items = readArticles();
  const item = {
    id: Date.now(),
    title, category,
    excerpt: excerpt || "",
    content,
    tags: Array.isArray(tags) ? tags : [],
    createdAt: new Date().toISOString()
  };
  items.unshift(item);
  writeArticles(items);
  res.status(201).json(item);
});

app.put("/api/articles/:id",(req,res)=>{
  const items = readArticles();
  const i = items.findIndex(a=>String(a.id)===String(req.params.id));
  if(i<0) return res.status(404).json({error:"المقال غير موجود"});
  items[i] = {...items[i], ...req.body, id:items[i].id};
  writeArticles(items);
  res.json(items[i]);
});

app.delete("/api/articles/:id",(req,res)=>{
  const items = readArticles();
  const next = items.filter(a=>String(a.id)!==String(req.params.id));
  if(next.length===items.length) return res.status(404).json({error:"المقال غير موجود"});
  writeArticles(next);
  res.json({ok:true});
});

app.get("/api/stats",(req,res)=>{
  const items=readArticles();
  res.json({
    articles:items.length,
    categories:[...new Set(items.map(x=>x.category))].length,
    generatedAt:new Date().toISOString()
  });
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,()=>console.log(`BAKO running: http://localhost:${PORT}`));